### Add Response Header Policy ###

#### Description

This policy can be used by API Gateway to add certain headers to the response created by the backend service, before hitting the client. You can add as much headers as you want, or you can overwrite a header in case it already exists in the message.

Example use case:

This policy is useful if you want to enrich a header that is provided by client, or provide a custom header to specify that the request is passing through the proxy. 

#### Configuration

After adding the custom policy to API Platform, you will have the possibility to include it in your API.
If you apply it, you will see a key-value tuple where you can include the header name and its value. If your client is already sending that header, its value will change by the one you write in that map. 
After completing those text areas, you have to press the plus button. This action will include your header in the policy and will let you include another one.
Once you finished including your headers, you can press Apply and the policy will start working (if you have an API Gateway already paired to your API).
You can also edit it whenever you want, by clicking the Edit button.