# TFS-MulePolicy-Custom-Logging
This custom policy used to provide log information for support purposes.

Has 2 parameters
  ## Logging Level
    (blank), VERBOSE, DEBUG
    blank - is standard logging as provided out of the box.
    VERBOSE - prints Message which includes all attributes
    DEBUG - prints Message and Payload
  ## PayloadQuery
  	Dataweave/MEL expression to query payload or other attributes as a way to extract information
  	
  _**WARNING** Due to a bug regarding null json payloads (get operations) DEBUG and PayloadQuery may not work_
