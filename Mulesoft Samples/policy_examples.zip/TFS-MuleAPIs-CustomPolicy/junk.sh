node('WN02'){
	def readPOM
	def envPropFile
	def envAnypointCloudhub
	def varClientID
	def varClientSecret
	def appName
	def scanAppName
	def pom
	def varAESKey

    //Set GIT repo URL
    String gitURL = 'https://github.tfs.toyota.com/EAS-Channel-Access-Services/TFS-MuleAPIs-API-Analytics'

    //Define artifactory URL and set credentials
    String artifactoryRootURL = 'https://artifactory.tfs.toyota.com/artifactory/'
    String artifactoryRepoName = "easc-maven-prod-local"
    def artifactoryServer = Artifactory.newServer url: artifactoryRootURL + artifactoryRepoName, credentialsId: 'easc_app.credentials'
    def artifactoryPublishServer = Artifactory.newServer url: artifactoryRootURL, credentialsId: 'easc_app.credentials'

    //Set artifactory build information and retention policy
	def buildInfo = Artifactory.newBuildInfo()
	buildInfo.name = "${env.JOB_BASE_NAME}"
	buildInfo.number = "${env.BUILD_NUMBER}"
	buildInfo.retention maxBuilds: 5
	buildInfo.retention deleteBuildArtifacts: true
	buildInfo.retention doNotDiscardBuilds: ["1"]

	//bypass proxy for artifactory
	artifactoryServer.bypassProxy=true
	artifactoryPublishServer.bypassProxy=true

	//set artifactory connnection timeouts
	artifactoryServer.connection.timeout = 300
	artifactoryPublishServer.connection.timeout = 300

    stage('Code Checkout'){
        //cleanup workspace removing files, directories, and any previous artifacts
        cleanWs()
	    // Get some code from a GitHub repository
        checkout([$class: 'GitSCM', branches: [[name: "bsauls/EASC-614"]], doGenerateSubmoduleConfigurations: false, extensions: [], submoduleCfg: [], userRemoteConfigs: [[credentialsId: 'easc_app.credentials', url: "${gitURL}"]]])
    }

	echo("Reading Properties from Build.Properties file from Git")

    //Code for pulling name/value pairs from build property file.  File is pulled from GitHub.
	def props = readProperties file:'./build.properties'
    appName = props['deploy.app.name']
    String deployBranchName = props['deploy.app.branch']
    String deployAppEnv = props['deploy.app.cloudhub.env']
    String deployAppBusGroup = props['deploy.app.BusinessGroup']
	String deployAppWorkerType = props['deploy.app.WorkerType']
	String deployAppclientidCredential	= props['deploy.app.platform.client_id_var']
	String deployAppclientsecretCredential = props['deploy.app.platform.client_secret_var']
	
	echo("Reading POM.xml to get the artifact ID")
	
	pom = readMavenPom file: 'pom.xml'
	String artifactID = pom.artifactId + "-mule-application.jar"
	String 
	echo "The artifactID is " + "${artifactID}"
	scanAppName = pom.artifactId + "-mule-application.zip"

	// select the env property file, workertype , client ID and Secret credentials
	stage('SetDeploymentVariables')
	{
		if(deployAppEnv=='DEV')
		{
			envPropFile = 'dev'
			envAnypointCloudhub = 'DEV'
			varClientID = 'ANYPOINT_DEV_CLIENT_ID'
			varClientSecret = 'ANYPOINT_DEV_CLIENT_SECRET'
			appName = "${appName}" + "-dev"
			varAESKey = 'AESKEY_DEV'
		}
		else if(deployAppEnv=='TEST')
		{
			envPropFile = 'test'
			envAnypointCloudhub = 'TEST'
			varClientID = 'ANYPOINT_TEST_CLIENT_ID'
			varClientSecret = 'ANYPOINT_TEST_CLIENT_SECRET'
			appName = "${appName}" + "-test"
			varAESKey = 'AESKEY_TEST'
		}
		else if(deployAppEnv=='PU-TEST')
		{
			envPropFile = 'pu-test'
			envAnypointCloudhub = 'PU-TEST'
			varClientID = 'ANYPOINT_PU_TEST_CLIENT_ID'
			varClientSecret = 'ANYPOINT_PU-TEST_CLIENT_SECRET'
			appName = "${appName}" + "-pu-test"
			varAESKey = 'AESKEY_PU_TEST'
		}
		else if(deployAppEnv=='STAGE')
		{
			envPropFile = 'stage'
			envAnypointCloudhub = 'STAGE'
			varClientID = 'ANYPOINT_STAGE_CLIENT_ID'
			varClientSecret = 'ANYPOINT_STAGE_CLIENT_SECRET'
			appName = "${appName}" + "-stage"
			varAESKey = 'AESKEY_STAGE'
		}
		else if(deployAppEnv=='PROD')
		{
			envPropFile = 'prod'
			envAnypointCloudhub = 'PROD'
			varClientID = 'ANYPOINT_PROD_CLIENT_ID'
			varClientSecret = 'ANYPOINT_PROD_CLIENT_SECRET'
			varAESKey = 'AESKEY_PROD'
		}
		else {
			echo "Not matched env property"
		}
	}
	
    // Artifactory configuration details
	stage ('Download Dependencies from Artifactory') 
	{
	    echo '********Download Project Dependencies from Artifactory********'
		def artifactoryServerMaven = Artifactory.newServer url: artifactoryRootURL, credentialsId: 'easc_app.credentials'
		def downloadSpec = """{
			"files":
			[
				{
					"pattern": "devops-maven-development-local/MavenRepo/repository.tar.gz",
					"target": "${HOME}/.m2/"
				}
			]
		}"""
        // Remove files from .m2 folder before downloading from Artifactory
        sh "rm -rf ${HOME}/.m2/"
        //Download Dependencies
        artifactoryServerMaven.download spec: downloadSpec
    }

    //Extract dependencies into maven repository
    stage('Build Repository') {
		echo '********Maven Cleans up artifacts created by Prior builds********'
        //untar dependencies tar.gz file to .m2 location
        sh "tar -C ${HOME}/.m2/ -zxf ${HOME}/.m2/MavenRepo/repository.tar.gz"
        sh "rm -rf ${HOME}/.m2/MavenRepo"
    }

    /*Determine deployment strategy based on property file environment variable.
        If environment is DEV, build, artifactory upload, publish build information
        If environment not DEV, artifactory download
    */
    if(deployAppEnv.equalsIgnoreCase('DEV')){
    	stage('MavenBuild'){
           //run maven build and package artifacts.  Ignore junit test failures.
            sh "_JAVA_OPTIONS=-Djdk.net.URLClassPath.disableClassPathURLCheck=true mvn clean package -Denv=${envPropFile} -Daeskey=${varAESKey} -Dmaven.test.failure.ignore=true"
            //sh 'mvn clean install -DskipTests'
    	}
		stage('VeracodeScan'){
            withCredentials([usernamePassword(credentialsId: 'Global_Credentials_Veracode', usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD')]) {
                sh "tar -cf tfs-MuleAPIs-${appName}build-${env.BUILD_NUMBER}.tar.gz src *.xml *.json -z"
                //bat(/"mv target\${artifactID} target\${scanAppName}"/)
    	        veracode applicationName: 'TMCC Tools and Disclosure', criticality: 'VeryHigh', autoscan: true, sandboxName: 'DEV', fileNamePattern: '', scanExcludesPattern: '', scanIncludesPattern: '**.xml,**.json,**.jar,**.yaml', scanName: "FACT0804_${appName}_Build-${env.BUILD_NUMBER}", uploadExcludesPattern: '', uploadIncludesPattern: '**/**.tar.gz', vid: '', vkey: '', vpassword: "${PASSWORD}", vuser: "${USERNAME}"
	        }
    	}
    	stage('ArtifactoryUpload'){
    	    //define the specification JSON used for uploading the artifacts.  Files is an array and can have multiple criteria.
    		def uploadSpec = """{
    			"files": [
    				{
    					"pattern": "./*.jar",
                        "target": "${env.JOB_BASE_NAME}",
                        "props" : "type=jar file"
    				},
    				{
    					"pattern": "./pom.xml",
                        "target": "${env.JOB_BASE_NAME}",
                        "props" : "type=pom file"
    				},
    				{
    					"pattern": "./mule-artifact.json",
                        "target": "${env.JOB_BASE_NAME}",
                        "props" : "type=json file"
    				}
				]
    		}"""
    		//call the artifactory upload method using the upload specification json variable with the build information.
			artifactoryServer.upload spec: uploadSpec, buildInfo: buildInfo
    	}
    	stage('PublishArtifactoryBuildInfo'){
    	    //publish the build informatioin to artifactory.  Artifactory will track the build history and artifacts.
            artifactoryPublishServer.publishBuildInfo buildInfo
    	}
    }
    else {
        stage('DownloadArtifact'){
            //Clear the workspace of previous artifacts to prepare for download
            cleanWs();

    	    //define the specification JSON used for downloading the artifacts.  Files is an array and can have multiple criteria.
            def downloadSpec = """{
             "files": [
                {
                "pattern": "${artifactoryRepoName}/${env.JOB_BASE_NAME}/*.jar",
                "target": "${WORKSPACE}/"
                },
                {
                "pattern": "${artifactoryRepoName}/${env.JOB_BASE_NAME}/pom.xml",
                "target": "${WORKSPACE}/"
                },
                {
                "pattern": "${artifactoryRepoName}/${env.JOB_BASE_NAME}/mule-artifact.json",
                "target": "${WORKSPACE}/"
                }
             ]
            }"""
    		//call the artifactory download method using the upload specification json variable.
            artifactoryPublishServer.download(downloadSpec)
        }
    }

    /*Prepare credentials to use with mule anypoint deployment.  Username and password plain text is replaced with ******.
    if environment is DEV deploy from workspace
    if environment not DEV, change directory and deploy from current directory
    */
    withCredentials([usernamePassword(credentialsId: 'ANYPOINT_FUNCTIONAL_USER', usernameVariable: 'USERNAME', passwordVariable: 'PASSWORD'), string(credentialsId: "${varClientID}", variable: 'CLIENT_ID'), string(credentialsId: "${varClientSecret}", variable: 'CLIENT_SECRET'),string(credentialsId: "${varAESKey}", variable: 'AESKEY')]) {
		stage('DeployToAnyPoint'){
	    	if(envAnypointCloudhub.equalsIgnoreCase('DEV'))
              //sh "mvn -Dmaven.test.failure.ignore=true deploy -DmuleDeploy -Dhttps.proxyHost=tfsproxy.tfs.toyota.com -Dhttps.proxyPort=80 -Danypoint.env=${envAnypointCloudhub} -Denv=${envPropFile} -Danypoint.platform.client_id=${CLIENT_ID} -Danypoint.platform.client_secret=${CLIENT_SECRET} -Daeskey=${AESKEY} -Danypoint.businessGroup=${deployAppBusGroup} -Dcloudhub.workerType=${deployAppWorkerType} -Danypoint.app=${appName} -Dmule.version=4.1.5 -Danypoint.username=${USERNAME} -Danypoint.password=${PASSWORD}"
              sh "_JAVA_OPTIONS=-Djdk.net.URLClassPath.disableClassPathURLCheck=true mvn clean install -Dmaven.test.failure.ignore=true deploy -DmuleDeploy -Danypoint.env=${envAnypointCloudhub} -Denv=${envPropFile} -Danypoint.platform.client_id=${CLIENT_ID} -Danypoint.platform.client_secret=${CLIENT_SECRET} -Daeskey=${AESKEY} -Danypoint.businessGroup=${deployAppBusGroup} -Dcloudhub.workerType=${deployAppWorkerType} -Danypoint.app=${appName} -Dmule.version=4.1.5 -Danypoint.username=${USERNAME} -Danypoint.password=${PASSWORD}"
    	    else
              sh "cd ${env.JOB_BASE_NAME}&& _JAVA_OPTIONS=-Djdk.net.URLClassPath.disableClassPathURLCheck=true mvn mule:deploy -Dmule.artifact=${artifactID} -Danypoint.env=${envAnypointCloudhub} -Denv=${envPropFile} -Danypoint.platform.client_id=${CLIENT_ID} -Danypoint.platform.client_secret=${CLIENT_SECRET} -Daeskey=${AESKEY} -Danypoint.businessGroup=${deployAppBusGroup} -Dcloudhub.workerType=${deployAppWorkerType} -Danypoint.app=${appName} -Dmule.version=4.1.5 -Danypoint.username=${USERNAME} -Danypoint.password=${PASSWORD}"
    	}
	}

	stage('NotifySuccess'){
        currentBuild.result = "SUCCESS"
        //notify(currentBuild.result)
	}
}


/*
Function to mail build status based on SUCCESS or FAILURE.
Mail includes the BUILD_NUMBER, BUILD_URL, and JOB_NAME
*/
def notify(String BuildStatus = 'SUCCESS', def ErrorOutput){
    if(BuildStatus == 'SUCCESS'){
        mail bcc: '', body: "Build ${BUILD_NUMBER} successful\n\nBUILD URL: ${env.BUILD_URL}", cc: '', from: 'no-reply@no-reply.com', replyTo: '', subject: "Build ${env.BUILD_NUMBER} SUCCESSFUL for ${env.JOB_NAME}", to: 'raamachanthiran.chanemougam@toyota.com'
    }
    else{
        mail bcc: '', body: "Build ${BUILD_NUMBER} failed\n\nReason: " + ErrorOutput + "\n\nBuild URL:  ${env.BUILD_URL}", cc: '', from: 'no-reply@no-reply.com', replyTo: '', subject: "Build ${env.BUILD_NUMBER} Failed for ${env.JOB_NAME}", to: 'raamachanthiran.chanemougam@toyota.com'
        error "Build ${BUILD_NUMBER} FAILED\n\nReason " + ErrorOutput
        throw ErrorOutput
    }
}

/*
Function to create JIRA issue.
*/

def createJiraDefect(){
    withEnv(['JIRA_SITE=http://www.some-jira-instance.com/devinstance']) {
        def buildIssue = [fields: [project: [id: '10000'],
                                    summary: 'New JIRA Created from Jenkins',
                                    description: 'New JIRA description',
                                    issuetype: [id: '3']]]
    response = jiraNewIssue issue: buildIssue
    echo response.successful.toString()
    echo.response.data.toString()
    }
}
