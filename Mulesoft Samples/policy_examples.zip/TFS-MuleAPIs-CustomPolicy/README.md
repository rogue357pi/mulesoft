# TFS-MuleAPIs-CustomPolicy

This custom policy API used to validate user session information passed in http header against Axway and Siteminder.
