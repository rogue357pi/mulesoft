# REST API - Mule App Template
*Bitbucket:* [*maven-archetype-rest-api*](TODO)

## Builds
Builds are deployments to Maven repository.

| Environment   | Status        | 
| :-------------: |:-------------:| 
| Development   |![Build Status](TODO)| 
| Production   |![Build Status](TODO)| 

## Description

This is the maven archetype for creating a Mule 4.x app for REST APIs.  It will generate a baseline application with the provided artifactId and groupId.
This project is fully runnable upon generation, after setting the `api.id` property.

## Features

- Standard maven definitions and dependencies in pom.xml.
- README template.
- Standard fields set to hidden, such as mule.vault.key.
- Standard API Kit with API RAML, API auto-discovery, and properties.
- Healthcheck RAML and flow.
- Standard Errors RAML Library.
- Security Schemes RAML Library.
- Standard API error handling flow.
- Global config file with all standard configs.
- Yaml secure and non-secure properties files for all environments.
- Standard log4j2.xml
- Proper naming and coding standards used in project and files.

## Usage

1. Open command prompt and change directory to where you want to create the project.
2. Run
    ```
    mvn archetype:generate -DarchetypeArtifactId=maven-archetype-rest-api -DarchetypeGroupId=<archetype's group id> -DarchetypeVersion=1.0 -DartifactId=my-new-app -DgroupId=<app's group id> -Dversion=1.0.0-SNAPSHOT -DinteractiveMode=false
    ```

    - archetypeArtifactId: artifactId of this archetype, which is `maven-archetype-rest-api`.
    - archetypeGroupId: groupId of this archetype.
    - archetypeVersion: version of this archetype.  Always use latest version.
    - artifactId: artifactId of your new app.
    - groupId: groupId of your new app.
    - version: version of your new app.  Generally start with `1.0.0-SNAPSHOT`.
3. Add API ID from specific API in API Manager to `api.id` property.  Environment property files are in `./src/main/resources/properties`.  This can be any number if doing local testing and not connecting to API Manager.
4. Start developing and testing app!

## Dependencies

- Maven installed on local system.
- Mule maven properly configured on local system.
- Network access to the Maven repository

## Development

Follow the Guide to [Creating Archetypes][maven-archetypes] when doing any development updates to archetype.

**Locations**
- Mule template app: `./src/main/resources/archetype-resources`
- Archetype descriptor: `./src/main/resources/META-INF/maven/archetype-metadata.xml`

If filtering files (<fileSet **filtered="true"** encoding="UTF-8">), then add the common replacements below at the top of each file and replace those values with the corresponding item.
Example: `${symbol_dollar}{some.mule.property}` instead of `${some.mule.property}`.
See [Maven Archetype Descriptor][maven-archetype-descriptor] doc.
```
#set( $symbol_pound = '#' )
#set( $symbol_dollar = '$' )
#set( $symbol_escape = '\' )
```


[maven-archetypes]: <https://maven.apache.org/guides/mini/guide-creating-archetypes.html>
[maven-archetype-descriptor]: <http://maven.apache.org/archetype/archetype-models/archetype-descriptor/archetype-descriptor.html>
