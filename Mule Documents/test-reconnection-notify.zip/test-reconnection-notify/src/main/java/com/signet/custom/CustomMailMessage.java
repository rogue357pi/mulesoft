package com.signet.custom;

import java.util.*;  
import javax.mail.*;  
import javax.mail.internet.*;
//import javax.activation.*;

import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

public class CustomMailMessage {

	private static final Logger logger = LogManager.getLogger();	// Log4j2 Logger

	private CustomMailMessage() {}

	public static void sendEmail(String to, String from, String host, String subject, String body) {
		
		logger.debug("Sending email message with subject [" + subject + "] to [" + to + "]"); 

		Properties properties = System.getProperties();  
		properties.setProperty("mail.smtp.host", host);
		Session session = Session.getDefaultInstance(properties);
		String multiRecipiants[] = to.split(",");
		int numRecipiants = multiRecipiants.length;
		int count = 0;

		try{  
			MimeMessage message = new MimeMessage(session);  
			message.setFrom(new InternetAddress(from));  
			if (numRecipiants > 1) {
				while (count < numRecipiants) {
					message.addRecipient(Message.RecipientType.TO,new InternetAddress(multiRecipiants[count]));
					count++;
				}
			} else {
				message.addRecipient(Message.RecipientType.TO,new InternetAddress(to));
			}
			//message.addRecipient(Message.RecipientType.TO,new InternetAddress(to));  
			message.setSubject(subject);  
			message.setText(body);  

			// Send message  
			Transport.send(message);  
			logger.debug("Email message sent successfully.");  

		} catch (MessagingException mex) {
			logger.error("Email message not sent successfully.", mex);
		} 
	}
}

