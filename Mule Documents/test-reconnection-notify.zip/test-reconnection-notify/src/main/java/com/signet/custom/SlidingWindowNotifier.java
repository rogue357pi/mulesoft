package com.signet.custom;

import com.signet.custom.CustomMailMessage;

import org.mule.api.retry.RetryContext;
import org.mule.api.retry.RetryNotifier;
import org.apache.logging.log4j.Logger;

import java.io.PrintWriter;
import java.io.StringWriter;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.apache.logging.log4j.LogManager;

public class SlidingWindowNotifier implements RetryNotifier {

	private static final Logger logger = LogManager.getLogger();	// Log4j2 Logger
	private Integer limit = 30;										// Error limit threshold.
	private Integer window = 60;									// Time window in seconds to check for connection errors.
	private Integer notificationDelay = 600;						// Seconds to wait before sending notification again.  This prevents repetitive emails.
	private Long nextNotification = 0L;								// Notifications are delayed until this time (epoch time).
	private List<Long> errorTimes = new ArrayList<Long>();			// List of times when a connection occurred.
	    
	// Email info
	private String project = "";
	private String toEmail = "";
    private String fromEmail = "";
    private String smtpRelay = "";
    private String environment = "";

	public SlidingWindowNotifier () {}

	/**
	 * Executes every time the retry mechanism fails on a retry.
	 */
	@Override
	public void onFailure(RetryContext context, Throwable e) {
		logger.error("Connection failed.");

		// Get floor (left boundary) of rolling window.
		Long currentTime = Instant.now().getEpochSecond();
		Long floor = currentTime - this.window;

		// Remove all error times not in the rolling window.
		this.errorTimes = this.errorTimes.stream().filter(time -> time >= floor).collect(Collectors.toList());

		// Add current error time.
		this.errorTimes.add(currentTime);

		Integer errorCount = this.errorTimes.size();

		if (errorCount >= this.limit) {
			// Error threshold was exceeded within the time window.
			logger.error("Exceeded connection error threshold of " + this.limit + " errors in " + this.window + " seconds.  Number of errors: " + errorCount);

			// Send notification email if exceeded notification delay.
			if (currentTime >= this.nextNotification) {
				logger.info("Exceeded delay for connection error notifications.  Sending notification.");
				this.nextNotification = currentTime + this.notificationDelay;

				// Send email.  TODO: call mule flow to send the email.
				this.sendEmailforError(e);		
			} else {
				logger.info("Did not exceed delay for connection error notifications.  Not sending notification.");
			}
		} else {
			// Error threshold was not exceeded within the time window.
			logger.debug("Did not exceed connection error threshold of " + limit + " errors in " + window + " seconds.  Number of errors: " + errorCount);
		}
	}

	/**
	 * Executes every time the retry mechanism is successful on a retry.
	 */
	@Override
	public void onSuccess(RetryContext context) {
		logger.info("Connection succeeded.");

		// Using rolling time window, so don't need to clear error time collection on success.
	}

	/**
	 * Converts a stack trace to a String
	 * 
	 * @param e Exception
	 * @return Exception's stack trace as a String.
	 */
	public String getStackTrace(Throwable e) {
		StringWriter sw = new StringWriter();
		e.printStackTrace(new PrintWriter(sw));
		String exceptionAsString = sw.toString();
		return exceptionAsString;
	}
	
	/**
	 * Sends email for the provided error.
	 * 
	 * @param e Exception
	 */
	private void sendEmailforError(Throwable e) {
		String message = getStackTrace(e);
		String subject = environment + " ALERT: " + project + " " + e.getLocalizedMessage();
		CustomMailMessage.sendEmail(toEmail, fromEmail, smtpRelay, subject, message);
	}

	public int getWindow() {
		return this.window;
	}

	public void setWindow(Integer window) {
		this.window = window;
		logger.debug("Time window for connection errors: " + window + " seconds");
	}

	public int getLimit() {
		return limit;
	}

	public void setLimit(int limit) {
		logger.debug("Max threshold during time window for connection errors: " + limit);
		this.limit = limit;
	}
	
	public Integer getNotificationDelay() {
		return notificationDelay;
	}

	public void setNotificationDelay(Integer notificationDelay) {
		this.notificationDelay = notificationDelay;
	}
	
	public String getProject() {
		return project;
	}

	public void setProject(String project) {
		this.project = project;
	}

	public String getToEmail() {
		return toEmail;
	}

	public void setToEmail(String toEmail) {
		this.toEmail = toEmail;
	}

	public String getFromEmail() {
		return fromEmail;
	}

	public void setFromEmail(String fromEmail) {
		this.fromEmail = fromEmail;
	}

	public String getSmtpRelay() {
		return smtpRelay;
	}

	public void setSmtpRelay(String smtpRelay) {
		this.smtpRelay = smtpRelay;
	}

	public String getEnvironment() {
		return environment;
	}

	public void setEnvironment(String environment) {
		this.environment = environment;
	}
}
